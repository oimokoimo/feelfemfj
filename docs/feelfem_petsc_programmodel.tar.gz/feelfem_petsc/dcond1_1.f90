module mod_dcond1_1
contains
subroutine dcond1_1(nsetno,firstNsetPtr,x,y,ipf,ipd,ipd_u,npmax,bc_mark,bc_value)
  use femDataType
  use feelP2data
  use numeric
  implicit none
  integer,intent(in) :: nsetno,npmax
  type(nsetList),pointer :: firstNsetPtr
  real(kind=REAL8),dimension(:),pointer :: x,y
  integer :: ipf(npmax),ipd(npmax),ipd_u(npmax)
  logical,intent(inout) :: bc_mark(:)
  real(kind=REAL8),intent(inout) :: bc_value(:)
  integer :: nd,ieq,nodes,np,i
  integer,dimension(:,:),pointer :: inset

  call setP2nset(nsetno,firstNsetPtr,nodes,np,inset)
  do i=1,nodes
    nd=inset(1,i)
    if(ipd_u(nd)==-1) cycle
    ieq=ipd(nd)+ipd_u(nd)
    bc_mark(ieq)=.true.
    bc_value(ieq)=1.0_REAL8
  end do
end subroutine dcond1_1
end module mod_dcond1_1
