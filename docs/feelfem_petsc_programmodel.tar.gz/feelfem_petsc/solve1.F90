#include <petsc/finclude/petscksp.h>
module mod_solve1
  use petscksp
  use femDataType
  use feelP2data
  use subsolveff90p2
  use report90
  use numeric
  use abortmodule
  use mod_elem1
  use mod_dcond1_1
  use mod_dcond1_2
  use mod_ipdinfo1_1
  implicit none
contains

subroutine solve1(npmax,x,y,firstEdatPtr,firstNsetPtr,solveLst,fem_f,fem_u,sc_k)
  implicit none
  integer(kind=INT4),intent(in) :: npmax
  real(kind=REAL8),dimension(:),pointer :: x,y
  type(edatList),pointer :: firstEdatPtr
  type(nsetList),pointer :: firstNsetPtr
  type(SolveList) :: solveLst
  real(kind=REAL8),dimension(:),pointer :: fem_f,fem_u
  real(kind=REAL8),intent(in) :: sc_k

  integer,parameter :: neg=1,maxElementNodes=3,dirichletSets=2,neumannSets=0
  integer :: i,j,no,nelem,np,netype,neq,solveNo,edatno,ncmax,nz_per_row
  integer,dimension(:,:),pointer :: ielem
  integer,dimension(:),pointer :: matno,ipd,ipf,ipd_u
  integer :: nenfre(maxElementNodes,neg)
  type(solveInformation),pointer :: solveInfoPtr
  type(boundaryDataSet),pointer :: bDatSetPtr
  logical,allocatable :: bc_mark(:)
  real(kind=REAL8),allocatable :: bc_value(:)

  Mat :: A
  Vec :: b,sol,xbc
  KSP :: ksp
  PC :: pc
  PetscErrorCode :: ierr
  PetscInt :: nbc,ii,its
  PetscInt,allocatable :: bc_rows(:),all_rows(:)
  PetscScalar,allocatable :: bc_vals(:),sol_vals(:)
  PetscReal :: rnorm
  KSPConvergedReason :: reason
  PetscLogDouble :: t0,t1

  data nenfre/1,1,1/

  call report('SOLVE 1 START (PETSc ProgramModel)')
  solveNo=1
  solveInfoPtr=>solveLst%solveDataList(solveNo)
  edatno=solveInfoPtr%edatno
  call setP2edat(edatno,firstEdatPtr,nelem,np,netype,ielem,matno)

  if(np/=maxElementNodes) stop 'PETSc solve1: element node count mismatch'
  if(dirichletSets/=solveInfoPtr%dconds) stop 'PETSc solve1: Dirichlet set count mismatch'
  if(neumannSets/=solveInfoPtr%nconds) stop 'PETSc solve1: Neumann set count mismatch'

  allocate(ipf(npmax),ipd(npmax),ipd_u(npmax))
  call makeipfp2(nenfre,maxElementNodes,neg,ielem,nelem,np,npmax,ipf)
  call makeipdp2(ipf,ipd,npmax,neq)
  call ipdinfo1_1(npmax,ielem,nelem,np,ipd_u)

  ! Safe uniform preallocation. For P1 triangles this is intentionally generous.
  call nc_connectp2(npmax,ielem,nelem,np,ncmax)
  nz_per_row=max(1,np*ncmax)
  write(*,'(a,i0,a,i0,a,i0)') 'PETSc: neq=',neq,', ncmax=',ncmax,', preallocation/row=',nz_per_row

  PetscCallA(MatCreateSeqAIJ(PETSC_COMM_SELF,int(neq,PETSC_INT_KIND), &
       int(neq,PETSC_INT_KIND),int(nz_per_row,PETSC_INT_KIND), &
       PETSC_NULL_INTEGER_ARRAY,A,ierr))
  PetscCallA(MatSetOption(A,MAT_NEW_NONZERO_ALLOCATION_ERR,PETSC_TRUE,ierr))
  ! ea(:,:) is a Fortran column-major two-dimensional array.
  PetscCallA(MatSetOption(A,MAT_ROW_ORIENTED,PETSC_FALSE,ierr))
  PetscCallA(VecCreateSeq(PETSC_COMM_SELF,int(neq,PETSC_INT_KIND),b,ierr))
  PetscCallA(VecDuplicate(b,sol,ierr))
  PetscCallA(VecDuplicate(b,xbc,ierr))
  PetscCallA(VecSet(b,0.0_PETSC_REAL_KIND,ierr))
  PetscCallA(VecSet(sol,0.0_PETSC_REAL_KIND,ierr))
  PetscCallA(VecSet(xbc,0.0_PETSC_REAL_KIND,ierr))

  PetscCallA(PetscTime(t0,ierr))
  call elem1(ielem,matno,nelem,np,x,y,ipf,ipd,npmax,fem_f,sc_k,A,b,neq)
  PetscCallA(MatAssemblyBegin(A,MAT_FINAL_ASSEMBLY,ierr))
  PetscCallA(MatAssemblyEnd(A,MAT_FINAL_ASSEMBLY,ierr))
  PetscCallA(VecAssemblyBegin(b,ierr))
  PetscCallA(VecAssemblyEnd(b,ierr))
  PetscCallA(PetscTime(t1,ierr))
  write(*,'(a,es14.6,a)') 'PETSc assembly time = ',t1-t0,' s'

  allocate(bc_mark(neq),bc_value(neq))
  bc_mark=.false.; bc_value=0.0_REAL8

  bDatSetPtr=>solveInfoPtr%dlst(1)
  do i=1,bDatSetPtr%nofsets
    no=bDatSetPtr%datlist(i)
    call dcond1_1(no,firstNsetPtr,x,y,ipf,ipd,ipd_u,npmax,bc_mark,bc_value)
  end do
  bDatSetPtr=>solveInfoPtr%dlst(2)
  do i=1,bDatSetPtr%nofsets
    no=bDatSetPtr%datlist(i)
    call dcond1_2(no,firstNsetPtr,x,y,ipf,ipd,ipd_u,npmax,bc_mark,bc_value)
  end do

  nbc=int(count(bc_mark),PETSC_INT_KIND)
  allocate(bc_rows(nbc),bc_vals(nbc))
  j=0
  do i=1,neq
    if(bc_mark(i)) then
      j=j+1
      bc_rows(j)=int(i-1,PETSC_INT_KIND)
      bc_vals(j)=real(bc_value(i),PETSC_REAL_KIND)
    end if
  end do
  if(nbc>0) then
    PetscCallA(VecSetValues(xbc,nbc,bc_rows,bc_vals,INSERT_VALUES,ierr))
    PetscCallA(VecAssemblyBegin(xbc,ierr))
    PetscCallA(VecAssemblyEnd(xbc,ierr))
    PetscCallA(MatZeroRowsColumns(A,nbc,bc_rows,1.0_PETSC_REAL_KIND,xbc,b,ierr))
  end if

  PetscCallA(KSPCreate(PETSC_COMM_SELF,ksp,ierr))
  PetscCallA(KSPSetOperators(ksp,A,A,ierr))
  ! Good default for this symmetric positive-definite Poisson/Helmholtz case.
  PetscCallA(KSPSetType(ksp,KSPCG,ierr))
  PetscCallA(KSPGetPC(ksp,pc,ierr))
  PetscCallA(PCSetType(pc,PCICC,ierr))
  PetscCallA(KSPSetTolerances(ksp,1.0e-12_PETSC_REAL_KIND, &
       PETSC_CURRENT_REAL,PETSC_CURRENT_REAL,PETSC_CURRENT_INTEGER,ierr))
  ! Command line options override defaults: -ksp_type, -pc_type, -ksp_rtol, ...
  PetscCallA(KSPSetFromOptions(ksp,ierr))

  PetscCallA(PetscTime(t0,ierr))
  PetscCallA(KSPSolve(ksp,b,sol,ierr))
  PetscCallA(PetscTime(t1,ierr))
  PetscCallA(KSPGetIterationNumber(ksp,its,ierr))
  PetscCallA(KSPGetResidualNorm(ksp,rnorm,ierr))
  PetscCallA(KSPGetConvergedReason(ksp,reason,ierr))
  write(*,'(a,es14.6,a)') 'PETSc solve time    = ',t1-t0,' s'
  write(*,'(a,i0,a,es14.6,a,i0)') 'PETSc iterations=',its,', residual=',rnorm,', reason=',reason
  if(reason<0) stop 'PETSc KSP diverged'

  ! Copy the PETSc solution back to the generated FEM variable.
  allocate(all_rows(neq),sol_vals(neq))
  do i=1,neq
    all_rows(i)=int(i-1,PETSC_INT_KIND)
  end do
  PetscCallA(VecGetValues(sol,int(neq,PETSC_INT_KIND),all_rows,sol_vals,ierr))
  do i=1,nelem
    do j=1,3
      no=ielem(j,i)
      fem_u(no)=real(sol_vals(ipd(no)),REAL8)
    end do
  end do

  deallocate(all_rows,sol_vals,bc_rows,bc_vals,bc_mark,bc_value)
  PetscCallA(KSPDestroy(ksp,ierr))
  PetscCallA(VecDestroy(xbc,ierr))
  PetscCallA(VecDestroy(sol,ierr))
  PetscCallA(VecDestroy(b,ierr))
  PetscCallA(MatDestroy(A,ierr))
  deallocate(ipd,ipf,ipd_u)
end subroutine solve1
end module mod_solve1
