#!/usr/bin/env python3
"""Compare skyline and PETSc node-value files.

Accepted rows: node x y fem_u. Lines beginning with # are ignored.
"""
import argparse
import math


def read_values(path):
    values = {}
    with open(path, encoding='utf-8') as f:
        for lineno, line in enumerate(f, 1):
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            cols = line.split()
            if len(cols) < 4:
                raise ValueError(f'{path}:{lineno}: expected node x y value')
            values[int(cols[0])] = float(cols[3])
    return values


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('skyline')
    ap.add_argument('petsc', nargs='?', default='fem_u_petsc.dat')
    args = ap.parse_args()
    a, b = read_values(args.skyline), read_values(args.petsc)
    common = sorted(set(a) & set(b))
    if not common:
        raise SystemExit('no common node numbers')
    missing_a = sorted(set(b) - set(a))
    missing_b = sorted(set(a) - set(b))
    diffs = [(i, b[i] - a[i]) for i in common]
    max_node, max_diff = max(diffs, key=lambda p: abs(p[1]))
    l2 = math.sqrt(sum(d*d for _, d in diffs))
    ref = math.sqrt(sum(a[i]*a[i] for i in common))
    print(f'nodes compared : {len(common)}')
    print(f'max abs diff   : {abs(max_diff):.16e} at node {max_node}')
    print(f'L2 diff        : {l2:.16e}')
    print(f'relative L2    : {(l2/ref if ref else float("nan")):.16e}')
    if missing_a: print(f'missing in skyline: {len(missing_a)}')
    if missing_b: print(f'missing in PETSc  : {len(missing_b)}')

if __name__ == '__main__':
    main()
