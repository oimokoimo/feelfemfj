module mod_quadrature_data1_1_1
  use numeric, only: REAL8
  implicit none

  integer, parameter :: NPG1 = 6

  real(kind=REAL8), save :: gx_1(NPG1), gy_1(NPG1), w_1(NPG1)
  real(kind=REAL8), save :: rP1_1_1(NPG1), rP1_1_x_1(NPG1), rP1_1_y_1(NPG1)
  real(kind=REAL8), save :: rP1_2_1(NPG1), rP1_2_x_1(NPG1), rP1_2_y_1(NPG1)
  real(kind=REAL8), save :: rP1_3_1(NPG1), rP1_3_x_1(NPG1), rP1_3_y_1(NPG1)

end module mod_quadrature_data1_1_1
