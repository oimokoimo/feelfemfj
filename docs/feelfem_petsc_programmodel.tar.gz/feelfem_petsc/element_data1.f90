module mod_element_data1
  use numeric, only: REAL8
  implicit none

  integer, parameter :: NDF_ELEMENT1 = 3
  real(kind=REAL8), save :: ea(NDF_ELEMENT1, NDF_ELEMENT1)
  real(kind=REAL8), save :: eb(NDF_ELEMENT1)

end module mod_element_data1
