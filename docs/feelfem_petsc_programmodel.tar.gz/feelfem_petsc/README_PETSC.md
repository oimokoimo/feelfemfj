# feelfem PETSc ProgramModel prototype

This directory is a PETSc replacement of the original skyline `solve1`.
It keeps the generated element integration routines and replaces only matrix
storage, boundary elimination, and the linear solver.

## Build

```sh
make -f Makefile.petsc PETSC_DIR=/path/to/petsc PETSC_ARCH=arch-linux-c-opt
```

For a prefix installation, the installation may not use `PETSC_ARCH`:

```sh
make -f Makefile.petsc PETSC_DIR=/path/to/petsc/install
```

## Run

Use the same `solv_dat` and `feel_dat` files as the skyline executable.

```sh
./feelfem_petsc -ksp_monitor -ksp_converged_reason
```

Defaults are CG + ICC. Runtime choices override them:

```sh
./feelfem_petsc -ksp_type cg -pc_type gamg -ksp_rtol 1e-12 -log_view
./feelfem_petsc -ksp_type bcgs -pc_type ilu -ksp_monitor
./feelfem_petsc -ksp_type gmres -pc_type ilu -ksp_gmres_restart 50
```

The solution is written to `fem_u_petsc.dat` as:

```text
node x y fem_u
```

## Compare with skyline

Add the same node loop to the skyline main program, writing
`fem_u_skyline.dat`, then run:

```sh
./compare_fem_u.py fem_u_skyline.dat fem_u_petsc.dat
```
