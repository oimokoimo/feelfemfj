module mod_quadrature_data1_1_2
  use numeric, only: REAL8
  implicit none

  integer, parameter :: NPG2 = 3

  real(kind=REAL8), save :: gx_2(NPG2), gy_2(NPG2), w_2(NPG2)
  real(kind=REAL8), save :: rP1_1_2(NPG2), rP1_1_x_2(NPG2), rP1_1_y_2(NPG2)
  real(kind=REAL8), save :: rP1_2_2(NPG2), rP1_2_x_2(NPG2), rP1_2_y_2(NPG2)
  real(kind=REAL8), save :: rP1_3_2(NPG2), rP1_3_x_2(NPG2), rP1_3_y_2(NPG2)

end module mod_quadrature_data1_1_2
