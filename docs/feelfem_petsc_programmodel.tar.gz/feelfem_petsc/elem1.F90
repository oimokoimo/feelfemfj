#include <petsc/finclude/petscksp.h>
module mod_elem1
  use petscksp
  use mod_ecal1_1
  use mod_element_data1, only: ea, eb
  use mod_eset1_1_1
  use mod_eset1_1_2
  use report90
  use numeric
  use abortmodule
  implicit none
contains

subroutine elem1(ielem,matno,nelem,np,x,y,ipf,ipd,npmax, &
                 fem_f,sc_k,A,b,neq)
  implicit none

  integer,dimension(:,:),pointer          :: ielem
  integer,dimension(:)  ,pointer          :: matno
  integer,intent(in)                      :: nelem,np,npmax,neq
  real(kind=REAL8),dimension(:),pointer   :: x,y
  integer,dimension(:),pointer            :: ipf,ipd
  real(kind=REAL8),dimension(:),pointer   :: fem_f
  real(kind=REAL8),intent(in)             :: sc_k
  Mat,intent(inout)                       :: A
  Vec,intent(inout)                       :: b

  integer,parameter :: NDF=3,NDP=3
  integer,parameter :: NPG1=6,NPG2=3
  integer :: i,j
  real(kind=REAL8) :: ex(NDP),ey(NDP),efem_f(NDP)
  integer :: ienp(NDF),iedp(NDF)
  PetscInt :: rows(NDF)
  PetscScalar :: peamat(NDF,NDF),peb(NDF)
  PetscErrorCode :: ierr

  data ienp/1,2,3/
  data iedp/0,0,0/

  call eset1_1_1
  call eset1_1_2

  do i=1,nelem
    do j=1,np
      ex(j)=x(ielem(j,i))
      ey(j)=y(ielem(j,i))
      efem_f(j)=fem_f(ielem(j,i))
    end do

    call ecal1_1(ex(1),ey(1),ex(2),ey(2),ex(3),ey(3), &
                 efem_f(1),efem_f(2),efem_f(3),sc_k)

    do j=1,NDF
      ! PETSc indices are zero based, including the Fortran interface.
      rows(j)=int(ipd(ielem(ienp(j),i))+iedp(j)-1,kind=PETSC_INT_KIND)
      peb(j)=real(eb(j),kind=PETSC_REAL_KIND)
    end do
    peamat(:,:)=real(ea(:,:),kind=PETSC_REAL_KIND)

    PetscCallA(MatSetValues(A,NDF,rows,NDF,rows,peamat,ADD_VALUES,ierr))
    PetscCallA(VecSetValues(b,NDF,rows,peb,ADD_VALUES,ierr))
  end do
end subroutine elem1
end module mod_elem1
